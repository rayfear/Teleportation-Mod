package com;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemTeleportationShards extends Item 
{
	
        public ItemTeleportationShards(int id) {
                super(id);
                setItemName("Teleportation shards");
                this.setCreativeTab(CreativeTabs.tabMaterials);	
          
        }
        
        public String getTextureFile()
        {
        	return "/teleportation/items/Items.png";
        }
      
    }
