package com;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;



public class BlockTretherBlock extends Block
{

	public BlockTretherBlock(int par1, int par2, Material par3Material) {
		super(par1,par2, Material.iron);
		 this.setCreativeTab(CreativeTabs.tabBlock);
	
	}
	 public String getTextureFile()
     {
     	return "/teleportation/blocks/Blocks.png";
     }
	
	
}
