package com;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;



public class TabMaterials extends CreativeTabs
{
	
	public TabMaterials(String label) {
	    super(label);
	}
	@Override
	public ItemStack getIconItemStack() {
	    return new ItemStack(TeleporterMod.ObsidianSticks);
	}
      
    }
