package com;



import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.client.MinecraftForgeClient;
import net.minecraftforge.common.Configuration;
import net.minecraftforge.common.DimensionManager;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.Init;
import cpw.mods.fml.common.Mod.PostInit;
import cpw.mods.fml.common.Mod.PreInit;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;

@Mod(modid="Teleport", name="TeleportationMod", version="1.4.7")
@NetworkMod(clientSideRequired=true, serverSideRequired=false)

public class TeleporterMod 
{
	public static CreativeTabs BlockTab = new TabTeleBlocks("TeleportBlocksTab");
	public static CreativeTabs ToolsTab = new TabTools("TeleportToolsTab");
	public static CreativeTabs WandTab = new TabWands("TeleportWandTab");
	public static CreativeTabs MaterialsTab = new TabMaterials("TeleportMaterialsTab");
	public final static Item Teleporter = new ItemTeleporter(5000).setIconCoord(1, 0);
	public final static Item ObsidianSticks = new ItemObsidianStick(5005).setIconCoord(3, 0);
	public final static Item TeleportationShards = new ItemTeleportationShards(3213).setIconCoord(2, 0);
	public final static Item TretherShards = new ItemTretherShards(5003).setIconCoord(4, 0);
	public final static Item TeleporterRemember = new Itemteleporterremember(4000).setIconCoord(0, 0);
	public final static Item FlintAndDiamond = new ItemFlintAndDiamond(6345).setIconCoord(5, 0);
    public static final Block TeleportingDirt = new BlockTeleportingDirt(153,2, Material.ground).setTextureFile("/teleportation/blocks/Blocks.png").setBlockName("TeleportingDirt").setHardness(1F);
    public static final BlockTpPortal portal = (BlockTpPortal) new BlockTpPortal(3645,7).setTextureFile("/teleportation/blocks/Blocks.png").setBlockName("TpPortal").setLightValue(2F).setHardness(1F);
    public static final Block TretherBlock = new BlockTretherBlock(156,6, Material.iron).setTextureFile("/teleportation/blocks/Blocks.png").setBlockName("TretherBlock").setHardness(5F);
    public static final BlockTpFire FireBlock = (BlockTpFire)(new BlockTpFire(155, 31)).setHardness(0.0F).setLightValue(1.0F).setBlockName("fire");
    public static final Block TeleportingGrass = new BlockTeleportingGrass(154,3, Material.grass).setTextureFile("/teleportation/blocks/Blocks.png").setBlockName("TeleportingGrass").setHardness(1F);
    public static final Block TeleportingOre = new BlockTeleportingOre(3055,1, Material.rock).setTextureFile("/teleportation/blocks/Blocks.png").setBlockName("TeleportingOre").setHardness(5F);
    public static final Block TretherOre = new BlockTretherOre(3032,5, Material.rock).setTextureFile("/teleportation/blocks/Blocks.png").setBlockName("TretherOre").setHardness(3F);
    public static int dimension = 20;
    public static BiomeGenBase teleportbiome = new BiomeGenTeleport(50).setColor(747097).setBiomeName("Tp").setMinMaxHeight(0.1F, 0.4F);
	public static WorldGenTeleportTrees worldGeneratorTeleTree = new WorldGenTeleportTrees(false, 4, 0, 0, false);
	
@Init
public void load(FMLInitializationEvent event)
{
	LanguageRegistry.instance().addStringLocalization("itemGroup.TeleportBlocksTab", "en_US", "Teleportation Blocks");
	LanguageRegistry.instance().addStringLocalization("itemGroup.TeleportWandTab", "en_US", "Teleportation Wands");
	LanguageRegistry.instance().addStringLocalization("itemGroup.TeleportMaterialsTab", "en_US", "Teleportation Materials");
	LanguageRegistry.instance().addStringLocalization("itemGroup.TeleportToolsTab", "en_US", "Teleportation Tools");
	TretherBlock.setCreativeTab(this.BlockTab);
	TeleportingDirt.setCreativeTab(this.BlockTab);
	TretherOre.setCreativeTab(this.BlockTab);
	TeleportingGrass.setCreativeTab(this.BlockTab);
	TeleportingOre.setCreativeTab(this.BlockTab);
	
	TretherShards.setCreativeTab(this.MaterialsTab);
	TeleportationShards.setCreativeTab(this.MaterialsTab);
	ObsidianSticks.setCreativeTab(this.MaterialsTab);
	FlintAndDiamond.setCreativeTab(this.ToolsTab);
	Teleporter.setCreativeTab(this.WandTab);
	TeleporterRemember.setCreativeTab(this.WandTab);
	
	GameRegistry.registerBlock(TeleportingDirt,"Teleporting Dirt");
	LanguageRegistry.addName(TeleportingDirt, "Teleporting Dirt");
	LanguageRegistry.addName(Teleporter, "Teleporter");
	LanguageRegistry.addName(TeleporterRemember, "Teleporter");
	GameRegistry.registerBlock(TeleportingGrass, "Teleporting Grass");
	LanguageRegistry.addName(TeleportingGrass, "Teleporting Grass");
	GameRegistry.registerBlock(TeleportingOre, "Teleportation Ore");
	LanguageRegistry.addName(TeleportingOre, "Teleportation Ore");
	GameRegistry.registerBlock(TretherOre, "Trether Ore");
	LanguageRegistry.addName(TretherOre, "Trether Ore");
	LanguageRegistry.addName(ObsidianSticks, "Obsidian Sticks");
	LanguageRegistry.addName(TretherShards, "Trether Shards");
	LanguageRegistry.addName(TeleportationShards, "Teleportation Shards");
	GameRegistry.registerBlock(TretherBlock, "Trether Block");
	LanguageRegistry.addName(TretherBlock, "Trether Block");
	LanguageRegistry.addName(portal, "Portal");
	GameRegistry.registerBlock(portal, "Portal");
	GameRegistry.registerBlock(FireBlock, "Fire");
	LanguageRegistry.addName(FireBlock, "Fire");
	LanguageRegistry.addName(FlintAndDiamond, "Flint and Diamond");
	DimensionManager.registerProviderType(dimension, WorldProviderTp.class, true);
	DimensionManager.registerDimension(dimension, dimension);
	
	ItemStack ObsidianStack = new ItemStack(Block.obsidian);
	ItemStack ObsidianStickStack = new ItemStack(ObsidianSticks);
	ItemStack TretherShardsStack = new ItemStack(TretherShards);
	ItemStack TeleportationShardsStack = new ItemStack(TeleportationShards);
	ItemStack FlintStack = new ItemStack(Item.flint);
	ItemStack DiamondStack = new ItemStack(Item.diamond);
	GameRegistry.addRecipe(new ItemStack(ObsidianSticks, 4), "x", "x", 
	        'x', ObsidianStack);
	GameRegistry.addRecipe(new ItemStack(TeleporterRemember, 1), "y", "x","x", 
	        'x', ObsidianStickStack, 'y', TeleportationShardsStack);
	
	GameRegistry.addRecipe(new ItemStack(Teleporter, 1), "y", "x","x", 
	        'x', ObsidianStickStack, 'y', TretherShardsStack);
	
	GameRegistry.addRecipe(new ItemStack(TretherBlock, 10), "ttt", "ttt","ttt", 
	      't', TretherShardsStack);
	
	GameRegistry.addRecipe(new ItemStack(FlintAndDiamond, 1), "d ", " f", 
		      'f', FlintStack,'d', DiamondStack);
	
	GameRegistry.registerWorldGenerator(new OreWorldGenerater());
	MinecraftForgeClient.preloadTexture("/teleportation/blocks/Blocks.png");


}






@PreInit
public void init(FMLPreInitializationEvent preEvent)
{
	
}
}