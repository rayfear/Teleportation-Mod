package com;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;



public class BlockTeleportStone extends Block
{

	public BlockTeleportStone(int par1, int par2, Material par3Material) {
		super(par1,par2, Material.rock);
		 this.setCreativeTab(CreativeTabs.tabBlock);
	
	}
	 public String getTextureFile()
     {
     	return "/teleportation/blocks/Blocks.png";
     }
	
	
}
