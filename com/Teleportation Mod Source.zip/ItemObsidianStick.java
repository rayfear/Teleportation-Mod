package com;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemObsidianStick extends Item 
{
	
        public ItemObsidianStick(int id) {
                super(id);
                setItemName("obsidian stick");
                this.setCreativeTab(CreativeTabs.tabMaterials);	
          
        }
        
        public String getTextureFile()
        {
        	return "/teleportation/items/Items.png";
        }
      
    }
