package com;

public class SavedLocation {
	   public SavedLocation() {
	
		
	}
	   public double _x;
	   public double _y;  
	   public double _z;
	
	
}
