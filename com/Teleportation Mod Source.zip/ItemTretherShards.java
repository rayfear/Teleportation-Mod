package com;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemTretherShards extends Item 
{
	
        public ItemTretherShards(int id) {
                super(id);
                setItemName("TretherShards");
                this.setCreativeTab(CreativeTabs.tabMaterials);	
          
        }
        
        public String getTextureFile()
        {
        	return "/teleportation/items/Items.png";
        }
      
    }
