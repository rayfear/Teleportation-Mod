package com;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;



public class TabTools extends CreativeTabs
{
	
	public TabTools(String label) {
	    super(label);
	}
	@Override
	public ItemStack getIconItemStack() {
	    return new ItemStack(TeleporterMod.FlintAndDiamond);
	}
      
    }
