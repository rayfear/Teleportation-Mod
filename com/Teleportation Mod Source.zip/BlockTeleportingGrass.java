package com;

import java.util.Random;

import com.TeleporterMod;


import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.world.IBlockAccess;



public class BlockTeleportingGrass extends Block
{

	public BlockTeleportingGrass(int par1, int par2, Material par3Material) {
		super(par1,par2, Material.grass);
		 this.setCreativeTab(CreativeTabs.tabBlock);
	
	}
	
	public int getBlockTextureFromSideAndMetadata(int par1, int par2)
    {
        return par1 == 1 ? 0 : (par1 == 0 ? 2 : 3);
    }

    @SideOnly(Side.CLIENT)

    /**
     * Retrieves the block texture to use based on the display side. Args: iBlockAccess, x, y, z, side
     */
    public int getBlockTexture(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        if (par5 == 1)
        {
            return 0;
        }
        else if (par5 == 0)
        {
            return 2;
        }
		return blockIndexInTexture;
     
        }
    public String getTextureFile()
    {
    	return "/teleportation/blocks/Blocks.png";
    }
	 
	 /**
	     * Returns the ID of the items to drop on destruction.
	     */
	    public int idDropped(int par1, Random par2Random, int par3)
	    {
	        return TeleporterMod.TeleportingDirt.blockID;
	    }
}
