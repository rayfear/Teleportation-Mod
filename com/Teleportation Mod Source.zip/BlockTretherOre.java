package com;

import java.util.Random;

import com.TeleporterMod;

import net.minecraft.block.BlockOre;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;



public class BlockTretherOre extends BlockOre
{

	public BlockTretherOre(int id, int texture, Material par3Material) {
		super(id,texture);
		 this.setCreativeTab(CreativeTabs.tabBlock);
	
	}
	 public String getTextureFile()
     {
     	return "/teleportation/blocks/Blocks.png";
     }
	
	 /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 2 + par1Random.nextInt(3);
    }

    /**
     * Returns the ID of the items to drop on destruction.
     */
    public int idDropped(int par1, Random par2Random, int par3)
    {
        return TeleporterMod.TretherShards.itemID;
    }
}
