package com;


import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemTeleporter extends Item 
{
	
        public ItemTeleporter(int id) {
                super(id);
                setItemName("teleporter");
                this.setCreativeTab(CreativeTabs.tabMisc);	
          
        }
        public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par2EntityPlayer)
        {
        	TeleporterClient teleporter = new TeleporterClient(par2World);
        	teleporter.placeInPortal(par2EntityPlayer, 0, 0, 0, 0);
            return par1ItemStack;
        
           
        }
        public String getTextureFile()
        {
        	return "/teleportation/items/Items.png";
        }
        public boolean hasEffect(ItemStack par1ItemStack)
        {
            return true;
        }
        public EnumRarity getRarity(ItemStack par1ItemStack)
        {
            return par1ItemStack.getItemDamage() == 0 ? EnumRarity.rare : EnumRarity.epic;
        }
    }
